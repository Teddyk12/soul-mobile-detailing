(()=>{var a={};a.id=156,a.ids=[156],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10720:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>E,patchFetch:()=>D,routeModule:()=>z,serverHooks:()=>C,workAsyncStorage:()=>A,workUnitAsyncStorage:()=>B});var d={};c.r(d),c.d(d,{POST:()=>y});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(51356),u=c(10641),v=c(28342);let w=process.env.RESEND_API_KEY||"",x=w?new v.u(w):null;async function y(a){if(!x||!w)return console.error("Resend API key not configured"),u.NextResponse.json({success:!1,error:"Email service not configured. Please add RESEND_API_KEY to environment variables."},{status:503});try{let b=await a.json(),c="soulmobiledetailingllc@gmail.com",d=`
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; background-color: #ffffff; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
    .content { background: #ffffff; padding: 30px; border: 1px solid #e0e0e0; }
    .details { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
    .detail-row { margin: 10px 0; }
    .label { font-weight: bold; color: #667eea; }
    .footer { background: #f8f9fa; padding: 20px; text-align: center; border-radius: 0 0 10px 10px; color: #666; font-size: 14px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Booking Confirmation</h1>
      <p>Soul Mobile Detailing LLC</p>
    </div>
    <div class="content">
      <p>Dear ${b.name},</p>
      <p>Thank you for booking with Soul Mobile Detailing LLC! We have received your booking request and will contact you shortly to confirm your appointment.</p>

      <div class="details">
        <h3 style="margin-top: 0; color: #667eea;">Booking Details</h3>
        <div class="detail-row"><span class="label">Service:</span> ${b.service}</div>
        <div class="detail-row"><span class="label">Date:</span> ${b.date}</div>
        <div class="detail-row"><span class="label">Time:</span> ${b.time}</div>
        <div class="detail-row"><span class="label">Address:</span> ${b.address}</div>
        <div class="detail-row"><span class="label">Vehicle Type:</span> ${b.vehicleType}</div>
        ${b.notes?`<div class="detail-row"><span class="label">Notes:</span> ${b.notes}</div>`:""}
      </div>

      <p><strong>What's Next?</strong></p>
      <p>Our team will reach out to you at ${b.phone} or ${b.email} within 24 hours to confirm your appointment details.</p>

      <p>If you have any questions in the meantime, feel free to contact us at ${c}.</p>

      <p>We look forward to making your vehicle shine!</p>
    </div>
    <div class="footer">
      <p><strong>Soul Mobile Detailing LLC</strong></p>
      <p>Email: ${c}</p>
      <p>This is an automated confirmation email.</p>
    </div>
  </div>
</body>
</html>
    `,e=`
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; background-color: #ffffff; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
    .content { background: #ffffff; padding: 30px; border: 1px solid #e0e0e0; }
    .details { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
    .detail-row { margin: 10px 0; }
    .label { font-weight: bold; color: #667eea; }
    .urgent { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; border-radius: 4px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🚗 New Booking Request</h1>
      <p>Soul Mobile Detailing LLC</p>
    </div>
    <div class="content">
      <div class="urgent">
        <strong>Action Required:</strong> A new customer has requested a detailing service. Please contact them to confirm.
      </div>

      <div class="details">
        <h3 style="margin-top: 0; color: #667eea;">Customer Information</h3>
        <div class="detail-row"><span class="label">Name:</span> ${b.name}</div>
        <div class="detail-row"><span class="label">Phone:</span> ${b.phone}</div>
        <div class="detail-row"><span class="label">Email:</span> ${b.email}</div>
        <div class="detail-row"><span class="label">Address:</span> ${b.address}</div>
      </div>

      <div class="details">
        <h3 style="margin-top: 0; color: #667eea;">Service Details</h3>
        <div class="detail-row"><span class="label">Service Requested:</span> ${b.service}</div>
        <div class="detail-row"><span class="label">Vehicle Type:</span> ${b.vehicleType}</div>
        <div class="detail-row"><span class="label">Preferred Date:</span> ${b.date}</div>
        <div class="detail-row"><span class="label">Preferred Time:</span> ${b.time}</div>
        ${b.notes?`<div class="detail-row"><span class="label">Additional Notes:</span> ${b.notes}</div>`:""}
      </div>

      <p><strong>Next Steps:</strong></p>
      <ol>
        <li>Contact the customer at ${b.phone} to confirm the appointment</li>
        <li>Verify the service address and any specific requirements</li>
        <li>Update the booking status in the admin panel</li>
      </ol>
    </div>
  </div>
</body>
</html>
    `,f=await x.emails.send({from:"Soul Mobile Detailing LLC <bookings@updates.same-assets.com>",to:b.email,subject:"Booking Confirmation - Soul Mobile Detailing LLC",html:d}),g=await x.emails.send({from:"Soul Mobile Detailing Bookings <bookings@updates.same-assets.com>",to:c,replyTo:b.email,subject:`🚗 New Booking: ${b.service} - ${b.date} at ${b.time}`,html:e});return u.NextResponse.json({success:!0,customerEmailId:f.data?.id,businessEmailId:g.data?.id})}catch(a){return console.error("Email sending error:",a),u.NextResponse.json({success:!1,error:a instanceof Error?a.message:"Failed to send emails"},{status:500})}}let z=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/send-booking-emails/route",pathname:"/api/send-booking-emails",filename:"route",bundlePath:"app/api/send-booking-emails/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"/home/project/soul-mobile-detailing/src/app/api/send-booking-emails/route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:A,workUnitAsyncStorage:B,serverHooks:C}=z;function D(){return(0,g.patchFetch)({workAsyncStorage:A,workUnitAsyncStorage:B})}async function E(a,b,c){var d;let e="/api/send-booking-emails/route";"/index"===e&&(e="/");let g=await z.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:A,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(y.dynamicRoutes[E]||y.routes[D]);if(F&&!x){let a=!!y.routes[D],b=y.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||z.isDev||x||(G="/index"===(G=D)?"/":G);let H=!0===z.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{cacheComponents:!!w.experimental.cacheComponents,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>z.onRequestError(a,b,d,A)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>z.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await z.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})},A),b}},l=await z.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await z.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},77598:a=>{"use strict";a.exports=require("node:crypto")},78335:()=>{},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},96487:()=>{}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[586,949],()=>b(b.s=10720));module.exports=c})();